//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ ���ɵİ����ļ���
// �� FTP_SERVER.rc ʹ��
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_FTP_SERVER_DIALOG           102
#define IDD_SEVERDLG                    107
#define IDR_MAINFRAME                   128
#define IDD_USERDLG                     131
#define IDD_LOGDLG                      132
#define IDD_USEREDIT                    135
#define IDD_LOG                         137
#define IDR_TRACE_MENU                  138
#define IDI_ICON_FTP                    146
#define IDI_ICON_BEIJING                147
#define IDC_TAB_LIST                    1000
#define IDC_EDIT_PORT                   1002
#define IDC_STATIC_NUMCON               1003
#define IDC_STATIC_PORT                 1004
#define IDC_STATIC_TIME                 1005
#define IDC_EDIT_NUMCON                 1006
#define IDC_EDIT_TIME                   1007
#define IDC_STATIC_WELCOME              1008
#define IDC_EDIT_WELCOME                1009
#define IDC_STATIC_GOODBYE              1010
#define IDC_EDIT_GOODBYE                1011
#define IDC_BTN_CON                     1012
#define IDC_BTN_CAL                     1013
#define IDC_STATIC_DANWEI               1014
#define IDC_LIST_USER                   1015
#define IDC_BTN_ADD                     1016
#define IDC_BTN_EDIT                    1017
#define IDC_LIST1                       1017
#define IDC_BTN_DEL                     1018
#define IDC_STATIC_USERNAME             1019
#define IDC_EDIT_USERNAME               1020
#define IDC_STATIC_PASS                 1021
#define IDC_EDIT_PASS                   1022
#define IDC_STATIC_REPASS               1023
#define IDC_EDIT_PASS2                  1024
#define IDC_STATIC_DIR                  1026
#define IDC_EDIT2                       1027
#define IDC_EDIT_FILEPATH               1027
#define IDC_BTN_CHOOSEFILE              1028
#define IDC_STATIC_USERROOT             1029
#define IDC_CHECK_DOWN                  1030
#define IDC_CHECK_UP                    1031
#define IDC_CHECK_RENAME                1032
#define IDC_CHECK_DEL                   1033
#define IDC_CHECK_MKDIR                 1034
#define IDC_BTN_YES                     1035
#define IDC_BTN_NO                      1036
#define IDC_LOGLIST                     1040
#define IDC_CHECK_ANON                  1052
#define IDC_LOGLIST1                    1053
#define PORT_BIND                       1821
#define DATA_BUFSIZE                    8192
#define WM_THREADSTART                  10001
#define WM_THREADSTOP                   10002
#define WM_THREADMESSAGE                10003
#define ID_TRACE_CLEAR                  32773

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        154
#define _APS_NEXT_COMMAND_VALUE         32775
#define _APS_NEXT_CONTROL_VALUE         1054
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
