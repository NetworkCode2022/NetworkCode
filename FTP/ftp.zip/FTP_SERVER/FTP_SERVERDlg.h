// FTP_SERVERDlg.h : header file
//

#if !defined(AFX_FTP_SERVERDLG_H__AD61C5B4_22A4_47BB_BEF5_9885956F0BE1__INCLUDED_)
#define AFX_FTP_SERVERDLG_H__AD61C5B4_22A4_47BB_BEF5_9885956F0BE1__INCLUDED_
#include "SeverDlg.h"
#include "UserDlg.h"
//#include "LogDlg.h"
#include "FtpEventsink.h"
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CFTP_SERVERDlg dialog

class CFTP_SERVERDlg : public CDialog,FtpEventSink
{
// Construction
public:
	SeverDlg m_serverdlg;
	UserDlg m_userdlg;
	//LogDlg m_logdlg;
	CDialog *mDialog[2];
	int m_curtab;
	CFTP_SERVERDlg(CWnd* pParent = NULL);	// standard constructor
    
	virtual void OnFTPStatusChange(int nType, LPCTSTR lpszText);
// Dialog Data
	//{{AFX_DATA(CFTP_SERVERDlg)
	enum { IDD = IDD_FTP_SERVER_DIALOG };
	CTabCtrl	m_tab_page;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFTP_SERVERDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CFTP_SERVERDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnSelchangeTabList(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FTP_SERVERDLG_H__AD61C5B4_22A4_47BB_BEF5_9885956F0BE1__INCLUDED_)
