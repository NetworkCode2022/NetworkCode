#if !defined(AFX_SEVERDLG_H__3CDC1237_4630_41E8_B0BF_2FF506FB7862__INCLUDED_)
#define AFX_SEVERDLG_H__3CDC1237_4630_41E8_B0BF_2FF506FB7862__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// SeverDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// SeverDlg dialog

class SeverDlg : public CDialog
{
// Construction
public:
    CEdit* c_serverport;
	CEdit* c_timeout;
	CEdit* c_maxlink;
    CEdit* c_welcome;
	CEdit* c_goodbye;
	CString m_ip;
	CString m_hostname;
	CButton * c_startbutton;
	CButton * c_stopbutton;
	WORD v;
	WSADATA wsData;
	SeverDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(SeverDlg)
	enum { IDD = IDD_SEVERDLG };
	int		m_port;
	CString	m_welcome;
	CString	m_goodbye;
	int		m_time;
	int		m_numcon;
	//}}AFX_DATA
public :
	void GetIP();
	void SStartComponentsState(BOOL state);
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(SeverDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(SeverDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnBtnStartFtp();
	afx_msg void OnBtnCloseFtp();
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	BOOL m_anonymous;
	afx_msg void OnClickedCheckAnon();

public:
	void AddTraceLine(int nLevel, LPCTSTR pstrFormat, ...);
	CListBox m_TraceList;
	CObList m_LogQueue;
	CCriticalSection m_QueueLock;

	class CLogMsg : public CObject
	{
	public:
		CLogMsg() {};
		virtual ~CLogMsg() {};
		SYSTEMTIME m_sysTime;
		int        m_nLevel;
		CString    m_strText;
	};
	LRESULT OnAddTraceLine(WPARAM, LPARAM);//�Զ�����Ϣ��Ӧ!!!!!!!!!!!!!!
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SEVERDLG_H__3CDC1237_4630_41E8_B0BF_2FF506FB7862__INCLUDED_)
