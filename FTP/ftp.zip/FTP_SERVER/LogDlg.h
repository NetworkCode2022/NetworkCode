#if !defined(AFX_LOGDLG_H__9F7F03E6_9978_47F0_9F9D_719EE5CF4CE9__INCLUDED_)
#define AFX_LOGDLG_H__9F7F03E6_9978_47F0_9F9D_719EE5CF4CE9__INCLUDED_
#include "resource.h"
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// LogDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// LogDlg dialog

class LogDlg : public CDialog
{
// Construction
public:
	//void AddTraceLine(int nLevel,LPCTSTR pstrFormat,...);
	LogDlg(CWnd* pParent = NULL);   // standard constructor
    CObList m_LogQueue;
	CCriticalSection m_QueueLock;

	class CLogMsg : public CObject
	{
	public:
		CLogMsg() {};
		virtual ~CLogMsg() {};
		SYSTEMTIME m_sysTime;
		int        m_nLevel;
		CString    m_strText;
	};
// Dialog Data
	//{{AFX_DATA(LogDlg)
	enum { IDD = IDD_LOG };
	CListBox	m_TraceList1;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(LogDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL
 //   LRESULT OnAddTraceLine(WPARAM, LPARAM); 
// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(LogDlg)
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);
	afx_msg void OnTraceClear();
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	//}}AFX_MSG
//	LRESULT OnAddTraceLine(WPARAM, LPARAM);//�Զ�����Ϣ��Ӧ!!!!!!!!!!!!!!
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_LOGDLG_H__9F7F03E6_9978_47F0_9F9D_719EE5CF4CE9__INCLUDED_)
