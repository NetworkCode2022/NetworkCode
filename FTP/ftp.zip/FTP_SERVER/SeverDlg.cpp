// SeverDlg.cpp : implementation file
//

#include "StdAfx.h"
#include "FTP_SERVER.h"
#include "SeverDlg.h"
#include "Sever.h"
#include "UserDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// SeverDlg dialog
bool state;
UserDlg miniSample;
extern Sever cServer;
SeverDlg::SeverDlg(CWnd* pParent /*=NULL*/)
	: CDialog(SeverDlg::IDD, pParent)
	//, anonymous(FALSE)
	, m_anonymous(FALSE)
{
	//{{AFX_DATA_INIT(SeverDlg)
	m_port = 0;
	m_welcome = _T("");
	m_goodbye = _T("");
	m_time = 0;
	m_numcon = 0;
	//}}AFX_DATA_INIT
}


void SeverDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(SeverDlg)
	DDX_Text(pDX, IDC_EDIT_PORT, m_port);
	DDX_Text(pDX, IDC_EDIT_WELCOME, m_welcome);
	DDX_Text(pDX, IDC_EDIT_GOODBYE, m_goodbye);
	DDX_Text(pDX, IDC_EDIT_TIME, m_time);
	DDX_Text(pDX, IDC_EDIT_NUMCON, m_numcon);
	//}}AFX_DATA_MAP
	//  DDX_Control(pDX, IDC_CHECK_ANON, anonymous);
	DDX_Check(pDX, IDC_CHECK_ANON, m_anonymous);
	DDX_Control(pDX, IDC_LOGLIST1, m_TraceList);
}


BEGIN_MESSAGE_MAP(SeverDlg, CDialog)
	//{{AFX_MSG_MAP(SeverDlg)
	ON_BN_CLICKED(IDC_BTN_CON, OnBtnStartFtp)
	ON_BN_CLICKED(IDC_BTN_CAL, OnBtnCloseFtp)
	ON_WM_CTLCOLOR()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_CHECK_ANON, &SeverDlg::OnClickedCheckAnon)
	ON_MESSAGE(WM_ADDTRACELINE, OnAddTraceLine)//����Ϣ������Ϣ����Ӧ����
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// SeverDlg message handlers

BOOL SeverDlg::OnInitDialog() 
{
//	CDialog::OnInitDialog();
	c_serverport=(CEdit*)GetDlgItem(IDC_EDIT_PORT);
	c_timeout = (CEdit*)GetDlgItem(IDC_EDIT_TIME);
	c_maxlink = (CEdit*)GetDlgItem(IDC_EDIT_NUMCON);
	c_welcome = (CEdit*)GetDlgItem(IDC_EDIT_WELCOME);
	c_goodbye = (CEdit*)GetDlgItem(IDC_EDIT_GOODBYE);
	c_startbutton = (CButton*)GetDlgItem(IDC_BTN_CON);
	c_stopbutton = (CButton*)GetDlgItem(IDC_BTN_CAL);
	c_serverport->SetWindowText("21");
	c_timeout->SetWindowText("10");
	c_maxlink->SetWindowText("10");
	//c_welcome->SetWindowText("��ӭ����FTP������");
	//c_goodbye->SetWindowText("BYE");
	CEdit *edit = (CEdit*)GetDlgItem(IDC_EDIT_WELCOME);
	edit->ShowWindow(FALSE);
	GetDlgItem(IDC_EDIT_GOODBYE)->ShowWindow(FALSE);

    GetIP();
//	MessageBox(m_ip);
	UpdateData(TRUE);
	// TODO: Add extra initialization here
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void SeverDlg::OnBtnStartFtp() 
{
	// TODO: Add your control notification handler code here   
    UpdateData(TRUE);
	v = MAKEWORD(1, 1);
	WSAStartup(v, &wsData); // �����׽��ֿ�    
	cServer.m_serverip= m_ip;
	cServer.m_serverport = m_port; 
	cServer.m_maxlink = m_numcon;
	cServer.m_timeout = m_time;
	cServer.m_welcomeInfor = m_welcome;
	cServer.m_goodbyeInfor = m_goodbye;
	if(cServer.ServerStart()){
		SStartComponentsState(TRUE);
	}
	else{
		MessageBox("����������ʧ��");
	}
    
}

void SeverDlg::OnBtnCloseFtp() 
{
	// TODO: Add your control notification handler code here
	cServer.ServerStop();
    SStartComponentsState(FALSE);
	WSACleanup(); 
	
}
void SeverDlg::SStartComponentsState(BOOL state)
{
	if(state)
	{//����״̬������㿪�����񣬾�Ĭ����Щ����Ϊֻ��
        c_maxlink->SetReadOnly(TRUE);
		c_timeout->SetReadOnly(TRUE);
		c_goodbye->SetReadOnly(TRUE);
		c_welcome->SetReadOnly(TRUE);
		c_serverport->SetReadOnly(TRUE);
	    c_startbutton->EnableWindow(FALSE);
		c_stopbutton->EnableWindow(TRUE);

    }else{
        c_maxlink->SetReadOnly(FALSE);
		c_timeout->SetReadOnly(FALSE);
		c_goodbye->SetReadOnly(FALSE);
		c_welcome->SetReadOnly(FALSE);
		c_serverport->SetReadOnly(FALSE);
		c_startbutton->EnableWindow(TRUE);
		c_stopbutton->EnableWindow(TRUE);
	}
}
void SeverDlg::GetIP()
{
 WSADATA wsData;
::WSAStartup(MAKEWORD(2,2), &wsData); //�����ȡʧ�ܣ��������������д��룻�����ȡ�ɹ�������Բ�����
   	char szhostname[128];
	CString str;
	if(gethostname(szhostname,128)==0) //���������
	{
		//�������IP��ַ
		struct hostent* phost;
		int occurred;
		phost=gethostbyname(szhostname);//�������������IP��ַ
		m_hostname=szhostname;
        occurred=0;
		int j;
		int h_length=4;
		for(j=0;j<h_length;j++)
		{
			CString addr;

			if(j>0)
				str+=".";
			addr.Format("%u",(unsigned int)((unsigned char*)phost->h_addr_list[occurred])[j]);
			str+=addr;
		}
	}
	m_ip=str;
}



HBRUSH SeverDlg::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CDialog::OnCtlColor(pDC, pWnd, nCtlColor);
	
	// TODO: Change any attributes of the DC here
		if (nCtlColor == CTLCOLOR_BTN)          //���İ�ť��ɫ  
    {  
        //pDC->SetBkMode(TRANSPARENT);  
        pDC->SetTextColor(RGB(0, 0, 0));  
        pDC->SetBkColor(RGB(255,255,255));  
        HBRUSH b = CreateSolidBrush(RGB(255,255,255));  
        return b;  
    }  
    else if (nCtlColor == CTLCOLOR_SCROLLBAR)  //  
    {  
        //pDC->SetBkMode(TRANSPARENT);  
        pDC->SetTextColor(RGB(0, 0, 0));  
        pDC->SetBkColor(RGB(255,255,255));  
        HBRUSH b = CreateSolidBrush(RGB(255,255,255));  
        return b;  
    }  
    else if (nCtlColor == CTLCOLOR_EDIT)   //���ı༭��  
    {  
        //pDC->SetBkMode(TRANSPARENT);  
        pDC->SetTextColor(RGB(0, 0, 0));  
        pDC->SetBkColor(RGB(255,255,255));  
        HBRUSH b = CreateSolidBrush(RGB(255,255,255));  
        return b;  
    }  
    else if (nCtlColor == CTLCOLOR_STATIC)  //���ľ�̬�ı�  
    {  
        pDC->SetTextColor(RGB(0, 0, 0));  
        pDC->SetBkColor(RGB(240, 240, 240));  //�ı䱳��
        HBRUSH b = CreateSolidBrush(RGB(240, 240, 240));
        return b;  
    }  
	// TODO: Return a different brush if the default is not desired
	return hbr;
}


void SeverDlg::OnClickedCheckAnon()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������

	if (m_anonymous == FALSE) {
		m_anonymous = TRUE;
		state = m_anonymous;
		miniSample.AddAnonymous();
	}
	else {
		m_anonymous = FALSE;
		state = m_anonymous;
		miniSample.AddAnonymous();
	}
}


void SeverDlg::AddTraceLine(int nLevel, LPCTSTR pstrFormat, ...)
{
	//���ݴ���Ĳ�����ʽ�����Ǹ���������
	CString str;
	va_list args;//����va_list�������ͱ���args���ñ������ʱ䳤�����б��еĲ�����

	//�����䳤����
	va_start(args, pstrFormat);//��ʹ��arg֮ǰ���������va_startʹ��arg�Ϳɱ�������й�����
	 //pstrFormat��ʡ�Ժ�"..."ǰ��һ����������va_start���ݴ˲������жϲ����б�����ʼλ�á�
	str.FormatV(pstrFormat, args);

	try
	{
		//������������ʾ
		CLogMsg *pLogMsg = new CLogMsg; //CLogMsg���Զ����һ����
		GetLocalTime(&pLogMsg->m_sysTime);
		pLogMsg->m_nLevel = nLevel;
		pLogMsg->m_strText = str;
		m_QueueLock.Lock();
		m_LogQueue.AddTail(pLogMsg);
		m_QueueLock.Unlock();
		//schedule log action
		PostMessage(WM_ADDTRACELINE);//	WM_ADDTRACELINE���Զ������Ϣ

	}
	catch (...)
	{
	}
}

LRESULT SeverDlg::OnAddTraceLine(WPARAM, LPARAM)
{
	CLogMsg *pLogMsg;

	try
	{
		//get first message in the queue
		pLogMsg = (CLogMsg*)m_LogQueue.RemoveHead();
		m_TraceList.AddString(pLogMsg->m_strText);
		delete pLogMsg;
	}
	catch (...)
	{
		//something is wrong...
	}
	return TRUE;
}

