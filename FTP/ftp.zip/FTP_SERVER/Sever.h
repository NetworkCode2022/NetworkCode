#if !defined(AFX_SEVER_H__0912077A_4462_429F_B689_0CD1BC5AB4FF__INCLUDED_)
#define AFX_SEVER_H__0912077A_4462_429F_B689_0CD1BC5AB4FF__INCLUDED_
#include "connectSocket.h"
#include "connectThread.h"
#include "resource.h"
#include "StdAfx.h"
#include "SeverAction.h"
#include "FtpEventSink.h"
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Sever.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// Sever window

class Sever : public CWnd
{
// Construction
public:
	Sever();

// Attributes
public:
    BOOL m_serverState;
	CString	m_serverip;
	UINT	m_serverport;
	CString	m_welcomeInfor;
	CString	m_goodbyeInfor;
	int     m_maxlink;
	int		m_timeout;
	int     m_linkcount;
    SeverAction cSPro;
	connectSocket m_cListenSocket;
    CTypedPtrList<CObList,connectThread*>  m_ServerThreadList; //�̳߳�
	CCriticalSection m_CriticalSection;
    
// Operations
public:
    BOOL ServerStart();
    BOOL ServerStop();
	LRESULT OnThreadStart(WPARAM wParam, LPARAM);
	LRESULT OnThreadStop(WPARAM wParam, LPARAM lParam);
	LRESULT OnThreadMessage(WPARAM wParam, LPARAM lParam);
	BOOL WaitWithMessageLoop(HANDLE hEvent, int nTimeout);
	void AddTraceLine(int nType, LPCTSTR pstrFormat, ...);
	FtpEventSink * m_pEventSink;
	void Initialize(FtpEventSink *pEventSink);
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(Sever)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~Sever();

	// Generated message map functions
protected:
	//{{AFX_MSG(Sever)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SEVER_H__0912077A_4462_429F_B689_0CD1BC5AB4FF__INCLUDED_)
