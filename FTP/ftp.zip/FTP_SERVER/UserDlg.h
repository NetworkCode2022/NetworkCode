#if !defined(AFX_USERDLG_H__70155C55_793A_4CFC_B93A_D781078EAE1D__INCLUDED_)
#define AFX_USERDLG_H__70155C55_793A_4CFC_B93A_D781078EAE1D__INCLUDED_
#include "UserInformation.h"
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// UserDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// UserDlg dialog

class UserDlg : public CDialog
{
// Construction
public:
	UserDlg(CWnd* pParent = NULL);   // standard constructor

	CArray<UserInformation, UserInformation&> m_userList;

// Dialog Data
	//{{AFX_DATA(UserDlg)
	enum { IDD = IDD_USERDLG };
	CListCtrl	m_cUserListCtrl;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(UserDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(UserDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnBtnAddUser();
    afx_msg void OnButtonUserDelete();
	afx_msg void OnButtonUserEdit() ;
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	void AddAnonymous();
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_USERDLG_H__70155C55_793A_4CFC_B93A_D781078EAE1D__INCLUDED_)
