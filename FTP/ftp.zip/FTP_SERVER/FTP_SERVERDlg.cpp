// FTP_SERVERDlg.cpp : implementation file
//

#include "stdafx.h"
#include "FTP_SERVER.h"
#include "FTP_SERVERDlg.h"
#include "Sever.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About
extern Sever cServer;
class CAboutDlg : public CDialog
{
public:

	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFTP_SERVERDlg dialog

CFTP_SERVERDlg::CFTP_SERVERDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CFTP_SERVERDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CFTP_SERVERDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CFTP_SERVERDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CFTP_SERVERDlg)
	DDX_Control(pDX, IDC_TAB_LIST, m_tab_page);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CFTP_SERVERDlg, CDialog)
	//{{AFX_MSG_MAP(CFTP_SERVERDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_NOTIFY(TCN_SELCHANGE, IDC_TAB_LIST, OnSelchangeTabList)
	ON_WM_CTLCOLOR()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFTP_SERVERDlg message handlers

BOOL CFTP_SERVERDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	CFont * f;
	f = new CFont;
	f->CreateFont(
		20, // nHeight
		0, // nWidth
		0, // nEscapement
		0, // nOrientation
		FALSE, // nWeight
		FALSE, // bItalic
		FALSE, // bUnderline
		0, // cStrikeOut
		ANSI_CHARSET, // nCharSet
		OUT_DEFAULT_PRECIS, // nOutPrecision
		CLIP_DEFAULT_PRECIS, // nClipPrecision
		DEFAULT_QUALITY, // nQuality
		DEFAULT_PITCH | FF_SWISS, // nPitchAndFamily
		_T("����") // lpszFac
	); 
   
    GetDlgItem(IDC_TAB_LIST)->SetFont(f);
	m_tab_page.InsertItem(0,_T("��������Ϣ"));
    m_tab_page.InsertItem(1,_T("�û���Ϣ"));
	//m_tab_page.InsertItem(2,_T("��־��Ϣ"));
	m_serverdlg.Create(IDD_SEVERDLG,&m_tab_page);
	m_userdlg.Create(IDD_USERDLG,&m_tab_page);
	//m_logdlg.Create(IDD_LOG,&m_tab_page);
	CRect rs;
	m_tab_page.GetClientRect(rs);
	rs.top+=30;
	m_serverdlg.MoveWindow(rs);
	m_userdlg.MoveWindow(rs);
//	m_logdlg.MoveWindow(rs);
	mDialog[0]=&m_serverdlg;
	mDialog[1]=&m_userdlg;
	//mDialog[2]=&m_logdlg;
    mDialog[0]->ShowWindow(SW_SHOW);
	mDialog[1]->ShowWindow(SW_HIDE);
	//mDialog[2]->ShowWindow(SW_HIDE);
	m_curtab=0;
	m_tab_page.SetCurSel(0);
    cServer.Initialize(this);
	// TODO: Add extra initialization here	
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CFTP_SERVERDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CFTP_SERVERDlg::OnPaint() 
{
	
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);
        

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

        dc.FillSolidRect(rect, RGB(0,0,0));

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}

	
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CFTP_SERVERDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CFTP_SERVERDlg::OnSelchangeTabList(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
   mDialog[m_curtab]->ShowWindow(SW_HIDE);
   m_curtab = m_tab_page.GetCurSel();
   mDialog[m_curtab]->ShowWindow(SW_SHOW);
   *pResult = 0;
}
void CFTP_SERVERDlg::OnFTPStatusChange(int nType, LPCTSTR lpszText)
{
	//m_logdlg.AddTraceLine(nType, lpszText);
	m_serverdlg.AddTraceLine(nType, lpszText);
}


HBRUSH CFTP_SERVERDlg::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CDialog::OnCtlColor(pDC, pWnd, nCtlColor);
	
	// TODO: Change any attributes of the DC here
	if (nCtlColor == CTLCOLOR_BTN)          //���İ�ť��ɫ  
    {  
        //pDC->SetBkMode(TRANSPARENT);  
        pDC->SetTextColor(RGB(0, 0, 0));  
        pDC->SetBkColor(RGB(0, 0, 0));  
        HBRUSH b = CreateSolidBrush(RGB(255,255,255));  
        return b;  
    }  
    else if (nCtlColor == CTLCOLOR_SCROLLBAR)  //  
    {  
        //pDC->SetBkMode(TRANSPARENT);  
        pDC->SetTextColor(RGB(0, 0, 0));  
        pDC->SetBkColor(RGB(0, 0, 0));  
        HBRUSH b = CreateSolidBrush(RGB(255,255,255));  
        return b;  
    }  
    else if (nCtlColor == CTLCOLOR_EDIT)   //���ı༭��  
    {  
        //pDC->SetBkMode(TRANSPARENT);  
        pDC->SetTextColor(RGB(0, 0, 0));  
        pDC->SetBkColor(RGB(0, 0, 0));  
        HBRUSH b = CreateSolidBrush(RGB(255,255,255));  
        return b;  
    }  
    else if (nCtlColor == CTLCOLOR_STATIC)  //���ľ�̬�ı�  
    {  
        pDC->SetTextColor(RGB(0, 0, 0));  
        pDC->SetBkColor(RGB(0, 0, 0));  
        HBRUSH b = CreateSolidBrush(RGB(0,0,0));  
        return b;  
    }  
    else if (nCtlColor == CTLCOLOR_DLG)   //���ĶԻ��򱳾�ɫ  
    {  
        pDC->SetTextColor(RGB(0, 0, 0));  
        pDC->SetBkColor(RGB(252,230,202));  
        HBRUSH b = CreateSolidBrush(RGB(255,255,255));  
        return b;  
    }  
  
	// TODO: Return a different brush if the default is not desired
	return hbr;
}

