// UserDlg.cpp : implementation file
//

#include "stdafx.h"
#include "FTP_SERVER.h"
#include "UserDlg.h"
#include "UsereditDlg.h"
#include "Sever.h"
#include "UserInformation.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// UserDlg dialog
extern bool state;
extern Sever cServer;
int index_anonymous = 0;
int count = 0;
UserDlg::UserDlg(CWnd* pParent /*=NULL*/)
	: CDialog(UserDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(UserDlg)
	//}}AFX_DATA_INIT
}


void UserDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(UserDlg)
	DDX_Control(pDX, IDC_LIST_USER, m_cUserListCtrl);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(UserDlg, CDialog)
	//{{AFX_MSG_MAP(UserDlg)
	ON_BN_CLICKED(IDC_BTN_ADD, OnBtnAddUser)
	ON_BN_CLICKED(IDC_BTN_DEL, OnButtonUserDelete)
	ON_BN_CLICKED(IDC_BTN_EDIT, OnButtonUserEdit)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// UserDlg message handlers

BOOL UserDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	m_cUserListCtrl.InsertColumn(0, _T("�û���"), LVCFMT_CENTER, 128);//����������
//	m_userlist.InsertColumn(1, _T("״̬"), LVCFMT_CENTER, 60);
	m_cUserListCtrl.InsertColumn(1, _T("Ŀ¼"), LVCFMT_CENTER, 160);
	m_cUserListCtrl.InsertColumn(2, _T("Ȩ��"), LVCFMT_CENTER, 260);
	
	//////////////


	////////////////
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void UserDlg::OnBtnAddUser() 
{
	// TODO: Add your control notification handler code here
	UsereditDlg dialog;
	//��ȷ����ť��Żᱣ��
	if (dialog.DoModal() == IDOK)
	{
		for (int i = 0; i<m_cUserListCtrl.GetItemCount(); i++)
		{
			CString username;
			username = m_cUserListCtrl.GetItemText(i, 0);
			if (username.CompareNoCase(dialog.userAccountInfor.m_username) == 0)
			{
				MessageBox(_T("�û����ظ�"), _T("����"), MB_ICONERROR);;
				return;
			}
		}
		UserInformation userAccountInfor= dialog.userAccountInfor;
		int index = m_userList.Add(userAccountInfor);
		cServer.cSPro.m_UserAccountInforList.Add(userAccountInfor);  
		int nItem = m_cUserListCtrl.InsertItem(0, userAccountInfor.m_username);

		m_cUserListCtrl.SetItemText(nItem, 1, userAccountInfor.m_path);//ѡ��·��
		CString privileges = userAccountInfor.m_allowDownload ? _T("���� ") : _T("");//�ڽ�������ʾ
		privileges += userAccountInfor.m_allowUpload ? _T("�ϴ� ") : _T("");
		privileges += userAccountInfor.m_allowRename ? _T("������ ") : _T("");
		privileges += userAccountInfor.m_allowDelete ? _T("ɾ�� ") : _T("");
		privileges += userAccountInfor.m_allowCreateDirectory ? _T("����Ŀ¼ ") : _T("");
		m_cUserListCtrl.SetItemText(nItem,2, privileges);
		m_cUserListCtrl.SetItemData(nItem, index);//������ݵ����ú���Ҫ���Ժ�Ѱ���б��ϵ����ݶ�Ӧ�����ݽṹ��ʱҪ�õ�
		m_cUserListCtrl.SetItemState(nItem, LVIS_SELECTED, LVIS_SELECTED);
	} 
}
void UserDlg::OnButtonUserDelete() 
{
	// TODO: Add your control notification handler code here
	int selectUserIndex = m_cUserListCtrl.GetNextItem(-1, LVNI_ALL | LVNI_SELECTED);//ѡ���û���m_cUserListCtrl��õ����б�ѡ�еĵڼ���
	if (selectUserIndex == -1)//���ѡ�е�������0�У��˳�
		return;
	
	// ��ȡѡ���û�������
	int UserIndex = m_cUserListCtrl.GetItemData(selectUserIndex);
	m_userList.RemoveAt(UserIndex);
	cServer.cSPro.m_UserAccountInforList.RemoveAt(UserIndex);
	// ���б���ɾ����Ŀ
	m_cUserListCtrl.DeleteItem(UserIndex);

	//�����û��б�
	for (int i = 0; i < m_cUserListCtrl.GetItemCount(); i++)
	{
		int selectUserData = m_cUserListCtrl.GetItemData(i);
		if (selectUserData > UserIndex)
		{
			m_cUserListCtrl.SetItemData(i, selectUserData - 1);
		}
	}
}
void UserDlg::OnButtonUserEdit() 
{
	// TODO: Add your control notification handler code here
	int selectUserIndex = m_cUserListCtrl.GetNextItem(-1, LVNI_ALL | LVNI_SELECTED);
	if (selectUserIndex == -1)
		return;
	
	int arrayUserListIndex = m_cUserListCtrl.GetItemData(selectUserIndex);
	
	UsereditDlg userEditdlg;

	userEditdlg.userAccountInfor = m_userList[arrayUserListIndex];
	if (userEditdlg.DoModal() == IDOK)
	{
		m_userList[arrayUserListIndex] = userEditdlg.userAccountInfor;
	    cServer.cSPro.m_UserAccountInforList[arrayUserListIndex] = userEditdlg.userAccountInfor;
		m_cUserListCtrl.SetItemText(selectUserIndex, 0, userEditdlg.userAccountInfor.m_username);

		m_cUserListCtrl.SetItemText(selectUserIndex, 1, userEditdlg.userAccountInfor.m_path);
		CString privileges = userEditdlg.userAccountInfor.m_allowDownload ? _T("���� ") : _T("");
		privileges += userEditdlg.userAccountInfor.m_allowUpload ? _T("�ϴ� ") : _T("");
		privileges += userEditdlg.userAccountInfor.m_allowRename ? _T("������ ") : _T("");
		privileges += userEditdlg.userAccountInfor.m_allowDelete ? _T("ɾ�� ") : _T("");
		privileges += userEditdlg.userAccountInfor.m_allowCreateDirectory ? _T("����Ŀ¼ ") : _T("");
		m_cUserListCtrl.SetItemText(selectUserIndex, 2, privileges);
	}

}



void UserDlg::AddAnonymous( )
{
	// TODO: �ڴ˴�����ʵ�ִ���.
	if (state == TRUE) {
		//Ĭ������һ��anonymous�û�
		UsereditDlg dialog;
		UserInformation userAccountInfor = dialog.userAccountInfor;
		userAccountInfor.m_username = "anonymous";
		//Ĭ��ֻ�������غ�������
		userAccountInfor.m_allowRename = TRUE;
		userAccountInfor.m_allowDownload = TRUE;

		int index = m_userList.Add(userAccountInfor);
		index_anonymous = index;
		cServer.cSPro.m_UserAccountInforList.Add(userAccountInfor);
		int nItem = m_cUserListCtrl.InsertItem(0, userAccountInfor.m_username);

		m_cUserListCtrl.SetItemText(nItem, 1, userAccountInfor.m_path);//ѡ��·��
		CString privileges = userAccountInfor.m_allowDownload ? _T("���� ") : _T("");//�ڽ�������ʾ
		privileges += userAccountInfor.m_allowUpload ? _T("�ϴ� ") : _T("");
		privileges += userAccountInfor.m_allowRename ? _T("������ ") : _T("");
		privileges += userAccountInfor.m_allowDelete ? _T("ɾ�� ") : _T("");
		privileges += userAccountInfor.m_allowCreateDirectory ? _T("����Ŀ¼ ") : _T("");
		m_cUserListCtrl.SetItemText(nItem, 2, privileges);
		m_cUserListCtrl.SetItemData(nItem, index);//������ݵ����ú���Ҫ���Ժ�Ѱ���б��ϵ����ݶ�Ӧ�����ݽṹ��ʱҪ�õ�
		m_cUserListCtrl.SetItemState(nItem, LVIS_SELECTED, LVIS_SELECTED);
	}
	else {
		// TODO: Add your control notification handler code here
		// ��ȡѡ���û�������
		int UserIndex = m_cUserListCtrl.GetItemData(index_anonymous);
		m_userList.RemoveAt(UserIndex);
		cServer.cSPro.m_UserAccountInforList.RemoveAt(UserIndex);
		// ���б���ɾ����Ŀ
		m_cUserListCtrl.DeleteItem(UserIndex);

		//�����û��б�
		for (int i = 0; i < m_cUserListCtrl.GetItemCount(); i++)
		{
			int selectUserData = m_cUserListCtrl.GetItemData(i);
			if (selectUserData > UserIndex)
			{
				m_cUserListCtrl.SetItemData(i, selectUserData - 1);
			}
		}
	}
}
