#if !defined(AFX_USEREDITDLG_H__8BDCCB02_E16D_4085_9CCF_0A29E002D425__INCLUDED_)
#define AFX_USEREDITDLG_H__8BDCCB02_E16D_4085_9CCF_0A29E002D425__INCLUDED_
#include "UserInformation.h"
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// UsereditDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// UsereditDlg dialog

class UsereditDlg : public CDialog
{
// Construction
public:
	UserInformation userAccountInfor;
	CString m_pass2;
//	CString m_dlgTitle;
	UsereditDlg(CWnd* pParent = NULL);   // standard constructor
    virtual BOOL OnInitDialog();
	virtual void OnOK();
// Dialog Data
	//{{AFX_DATA(UsereditDlg)
	enum { IDD = IDD_USEREDIT };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(UsereditDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
     
	// Generated message map functions
	//{{AFX_MSG(UsereditDlg)
	afx_msg void OnButtonSelectpath();
	afx_msg void OnBtnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnClickedBtnNo();
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_USEREDITDLG_H__8BDCCB02_E16D_4085_9CCF_0A29E002D425__INCLUDED_)
